CH Audio Match 0.3.0 - Windows x64 VST3
==================================================

系统要求：
- Windows 10 或 Windows 11，64 位
- 支持 VST3 的 64 位宿主，例如 REAPER

自动安装：
1. 先关闭 REAPER 或其他正在使用本插件的宿主。
2. 双击“安装 CH Audio Match.bat”。
3. 在 Windows 管理员授权窗口中选择“是”。
4. 重新打开 REAPER，执行 VST3 重新扫描。

手动安装：
将整个“CH Audio Match.vst3”文件夹复制到：
C:\Program Files\Common Files\VST3\

注意：
- 必须复制完整的 .vst3 文件夹，不要只复制 Contents 内部文件。
- 插件当前仅支持 Windows x64 VST3。
- 如果无法覆盖旧版本，请先关闭 REAPER。
