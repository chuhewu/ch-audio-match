@echo off
chcp 65001 >nul
setlocal

fltmc >nul 2>&1
if errorlevel 1 (
    powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

set "SOURCE=%~dp0CH Audio Match.vst3"
set "DEST=C:\Program Files\Common Files\VST3\CH Audio Match.vst3"

if not exist "%SOURCE%\Contents\x86_64-win\CH Audio Match.vst3" (
    echo 安装包不完整，找不到 VST3 文件。
    pause
    exit /b 1
)

if exist "%DEST%" rmdir /s /q "%DEST%"
xcopy "%SOURCE%" "%DEST%\" /e /i /h /y >nul

if exist "%DEST%\Contents\x86_64-win\CH Audio Match.vst3" (
    echo.
    echo CH Audio Match 安装成功。
    echo 请重新打开 REAPER 并扫描 VST3 插件。
    echo.
    pause
    exit /b 0
)

echo 安装失败。请关闭 REAPER 后重试。
pause
exit /b 1
